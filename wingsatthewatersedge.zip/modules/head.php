
<meta charset="utf-8">

<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="/javascript/appscripts.js"></script>
<script type="text/javascript" src="/ckeditor/ckeditor.js"></script>
<link rel="stylesheet" type="text/css" href="/CSS/Three%20Feature%20Gallery%20Template.css">
<link href='http://fonts.googleapis.com/css?family=Italianno|Open+Sans:400italic,800italic,400,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Quintessential|Herr+Von+Muellerhoff|Open+Sans:400italic,700italic,400,700' rel='stylesheet' type='text/css'>
